import { HovererDirective } from './hoverer.directive';

describe('HovererDirective', () => {
  it('should create an instance', () => {
    const directive = new HovererDirective();
    expect(directive).toBeTruthy();
  });
});
