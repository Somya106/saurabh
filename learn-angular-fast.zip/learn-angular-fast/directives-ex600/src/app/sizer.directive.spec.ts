import { SizerDirective } from './sizer.directive';

describe('SizerDirective', () => {
  it('should create an instance', () => {
    const directive = new SizerDirective();
    expect(directive).toBeTruthy();
  });
});
