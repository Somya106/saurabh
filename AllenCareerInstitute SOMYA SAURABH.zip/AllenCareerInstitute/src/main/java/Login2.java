import javax.servlet.*;
import java.io.*;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/Login2")
public class Login2 extends HttpServlet {
			@Override
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		String a=req.getParameter("t1");
		String b=req.getParameter("t2");
			if(a.equals("admin") && b.equals("1234"))
				res.sendRedirect("adminreport.html");
			else
				res.sendRedirect("adminlogin.html");
			}
	}	
		
	
